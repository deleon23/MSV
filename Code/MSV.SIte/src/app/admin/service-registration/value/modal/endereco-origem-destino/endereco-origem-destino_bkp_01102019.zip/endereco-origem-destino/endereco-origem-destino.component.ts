import { Component, OnInit, Input, EventEmitter, ViewChild } from '@angular/core';
import { EnderecoOrigemDestinoInput } from 'src/app/shared/entities/eod/eod';
import { EntidadeTipoEnderecoInput } from 'src/app/shared/entities/eod/eod-entidade-tipo-endereco';
import { FilialViewModel } from 'src/app/shared/entities/eod/eod-filial';
import { ClienteEntidadeViewModel } from 'src/app/shared/entities/eod/eod-cliente-entidade';
import { EntidadeAgenciaViewModel } from 'src/app/shared/entities/eod/eod-entidade-agencia';
import { TipoEquipamentoViewModel } from 'src/app/shared/entities/eod/eod-tipo-equipamento';
import { Observable } from 'rxjs';
import { EntidadeBancoViewModel } from 'src/app/shared/entities/eod/eod-entidade-banco';
import { DomSanitizer } from '@angular/platform-browser';
import { PropostaInput } from 'src/app/shared/entities/eod/eod-proposta';
import { TipoPropostaViewModel } from 'src/app/shared/entities/eod/eod-tipo-proposta';
import { EnderecoOrigemDestinoImportacaoViewModel } from 'src/app/shared/entities/eod/eod-importacao';

// import {
//   Component,
//   OnInit,
//   EventEmitter,
//   Input,
//   ViewChild
// } from '@angular/core';
// import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
// import { NotifyService } from 'app/utils/notify.service';
// import { Dados } from 'app/pages/comum/models/Dados';
// import { Ordenacao } from 'app/pages/comum/models/Ordenacao';
// import { BwsService } from 'app/pages/comum/bws.service';
// import { FiltroClienteEntidadeInput } from 'app/pages/comum/cliente-entidades/models/inputs/FiltroClienteEntidadeInput.model';
// import { ClienteEntidadeService } from 'app/pages/comum/cliente-entidades/cliente-entidade.service';
// import { PropostaInput } from 'app/pages/propostas/models/inputs/PropostaInput.model';
// import * as _ from 'lodash';
// import { EntidadeTipoEnderecoInput } from 'app/pages/comum/entidade-tipo-endereco/models/inputs/EntidadeTipoEnderecoInput.model';
// import { FilialViewModel } from 'app/pages/comum/filial/models/viewModels/FilialViewModel.model';
// import { EntidadeTipoEnderecoService } from 'app/pages/comum/entidade-tipo-endereco/entidade-tipo-endereco.service';
// import { EntidadeEnderecoService } from 'app/pages/comum/entidade-endereco/entidade-endereco.service';
// import { FilialService } from 'app/pages/comum/filial/filial.service';
// import { FilialInput } from 'app/pages/comum/filial/models/inputs/FilialInput.model';
// import { FiltroEntidadeEnderecoInput } from 'app/pages/comum/entidade-endereco/models/inputs/FiltroEntidadeEnderecoInput.model';
// import { EnderecoOrigemDestinoInput } from 'app/pages/propostas/proposta-steps/ponto-atendimento/endereco-origem-destino/inputs/EnderecoOrigemDestinoInput.model';
// import { EnderecoOrigemDestinoService } from './endereco-origem-destino.service';
// import { BwSStatus } from 'app/pages/propostas/proposta-steps/contratante/models/viewModels/PessoaJuridicaViewModel.model';
// import { Observable } from 'rxjs/Observable';
// import { Visualizacao } from '../../../../comum/models/Visualizacao';
// import { ClienteEntidadeViewModel } from '../../../../comum/cliente-entidades/models/viewModels/ClienteEntidadeViewModel.model';
// import { DomSanitizer } from '@angular/platform-browser';
// import { FiltroFilialInput } from '../../../../comum/filial/models/inputs/FiltroFilialInput.model';
// import { EntidadeBancoViewModel } from '../../../../comum/entidade-banco/models/viewModels/EntidadeBancoViewModel.model';
// import { FiltroEntidadeBancoInput } from '../../../../comum/entidade-banco/models/inputs/FiltroEntidadeBancoInput.model';
// import { EntidadeBancoService } from '../../../../comum/entidade-banco/entidade-banco.service';
// import { Opcoes } from '../../../../comum/models/Opcoes';
// import { EnderecoOrigemDestinoFilialComponent } from './pesquisa-filial/pesquisa-filial.component';
// import { ClienteEntidadeInput } from '../../../../comum/cliente-entidades/models/inputs/ClienteEntidadeInput.model';
// import { DateTimePickerComponent } from 'ng-pick-datetime/picker.component';
// import * as XLSX from 'xlsx';
// import { EntidadeAgenciaViewModel } from 'app/pages/comum/entidade-banco/models/viewModels/EntidadeAgenciaViewModel.model';
// import { TipoPropostaViewModel } from 'app/pages/tipo-proposta/models/viewModels/TipoPropostaViewModel';
// import { TipoEquipamentoViewModel } from 'app/pages/comum/tipo-equipamento/models/viewModels/TipoEquipamentoViewModel.model';
// import { FiltroTipoEquipamentoInput } from 'app/pages/comum/tipo-equipamento/models/inputs/FiltroTipoEquipamentoInput.model';
// import { TipoEquipamentoService } from 'app/pages/comum/tipo-equipamento/tipo-equipamento.service';
// import { EnderecoOrigemDestinoImportacaoViewModel } from './viewModels/EnderecoOrigemDestinoImportacaoViewModel.model';
// import { stringify } from 'querystring';

@Component({
  selector: 'endereco-origem-destino',
  templateUrl: './endereco-origem-destino.component.html',
  styleUrls: ['./endereco-origem-destino.component.scss']
})
export class EnderecoOrigemDestinoComponent implements OnInit {
  @ViewChild(DateTimePickerComponent)
  picker: DateTimePickerComponent;
  @Input()
  public visualizacao: boolean;
  @Input()
  public propostaInput: PropostaInput;
  @Input()
  public tipoPropostaInput: TipoPropostaViewModel;
  @Input()
  public pontosAtendimento: EnderecoOrigemDestinoInput[] = [];

  utilizaContratanteNaOrigem: boolean = true;
  textoContratanteNaOrigem: string = 'Utilizar Contratante';

  utilizaContratanteNoDestino: boolean = true;
  textoContratanteNoDestino: string = 'Utilizar Contratante';

  public entidadeTipoEnderecos_o: EntidadeTipoEnderecoInput[] = [];
  public entidadeTipoEnderecos_d: EntidadeTipoEnderecoInput[] = [];

  modalidadecreditoD0: boolean = false;
  modalidadecreditoD1: boolean = false;
  flgImpressaoEnderecoDestino: boolean = false;
  alterouFilial: boolean = false;
  @Input()
  public enderecoOrigemDestinoInput: EnderecoOrigemDestinoInput = new EnderecoOrigemDestinoInput();
  @Input()
  public pai_ID_PontoAtendimento: number;
  // @Input() public pai_cod_regional: number;
  // @Input() public pai_cod_entidadeBanco: number;

  public bloquearEdicaoRazaoSocialOrigem: boolean = true;
  public bloquearEdicaoRazaoSocialDestino: boolean = true;

  public bloquearEdicaoCnpjOrigem: boolean = false;
  public bloquearEdicaoCnpjDestino: boolean = false;

  public escolheuFilialOrigem: boolean = false;
  public escolheuFilialDestino: boolean = false;

  // Emiter para atualizar o Grid da Tela Pai
  public onEnderecoOrigemDestinoAdicionado: EventEmitter<
    EnderecoOrigemDestinoInput
  > = new EventEmitter();

  public filiais: FilialViewModel[] = [];
  // public filialViewModel: FilialViewModel;
  public filialViewModelPai: FilialViewModel;

  @Input()
  public clienteEntidadeOrigemViewModel: ClienteEntidadeViewModel;
  @Input()
  public clienteEntidadeDestinoViewModel: ClienteEntidadeViewModel;

  // para os campos busca dinamica
  public entidadeBancoViewModel: EntidadeBancoViewModel;
  public entidadeAgenciaViewModel: EntidadeAgenciaViewModel;
  public agencias: EntidadeAgenciaViewModel[] = [];
  public file: File;
  public arrayBuffer: any;
  public worksheet: any;
  public collapseUpload: boolean = false;
  public fileName: string = 'Arquivo de Importação (.xlsx)';
  public onInit: boolean;
  public tipoEquipamentoViewModel: TipoEquipamentoViewModel;
  public enderecosOrigemDestinoExcel: EnderecoOrigemDestinoInput[] = [];
  public enderecoOrigemDestinoImportacao = new EnderecoOrigemDestinoImportacaoViewModel();

  constructor(
    private modalRef: NgbActiveModal,
    private modalService: NgbModal,
    private notifyService: NotifyService,
    private entidadeTipoEnderecoService: EntidadeTipoEnderecoService,
    private bwsService: BwsService,
    private clienteEntidadeService: ClienteEntidadeService,
    private entidadeEnderecoService: EntidadeEnderecoService,
    private filialService: FilialService,
    private pontoAtendimentoOrigemDestinoService: EnderecoOrigemDestinoService,
    public enderecoOrigemDestinoService: EnderecoOrigemDestinoService,
    private _sanitizer: DomSanitizer,
    private entidadeBancoService: EntidadeBancoService,
    private tipoEquipamentoService: TipoEquipamentoService
  ) {}

  ngOnInit() {

    this.enderecoOrigemDestinoImportacao.TotalImportado = 0;
    this.enderecoOrigemDestinoImportacao.QuantidadeTotal = 0;
    this.enderecoOrigemDestinoImportacao.Mensagens = [];
    this.onInit = true;

    if (!this.enderecoOrigemDestinoInput) {
      this.enderecoOrigemDestinoInput = new EnderecoOrigemDestinoInput();
      if (this.enderecoOrigemDestinoInput.COD_PontoAtendimento > 0) {
        this.obterEnderecoOrigemDestino(
          this.enderecoOrigemDestinoInput.COD_PontoAtendimento
        );
      }
    }

    if(this.enderecoOrigemDestinoInput.DT_Base &&
      typeof this.enderecoOrigemDestinoInput.DT_Base === 'string')
      this.enderecoOrigemDestinoInput.DT_Base = new Date(this.enderecoOrigemDestinoInput.DT_Base);

    this.ObterEntidadeTipoEnderecos();
    this.escolheuFilialOrigem = false;
    this.escolheuFilialDestino = false;

    if (this.enderecoOrigemDestinoInput.COD_PontoAtendimento > 0) {
      this.obterFilial(
        this.enderecoOrigemDestinoInput.COD_Filial,
        this.enderecoOrigemDestinoInput.COD_Regional
      );
      if (this.enderecoOrigemDestinoInput.COD_EntidadeBanco > 0) {
        this.obterEntidadeBanco(
          this.enderecoOrigemDestinoInput.COD_EntidadeBanco
        );
      }

      if(this.enderecoOrigemDestinoInput.COD_TipoEquipamento) {
        this.modeloCofreObservableSource('')
            .subscribe(resultado => {
              this.tipoEquipamentoViewModel = _.find(resultado.Dados, te => te.Id_TpEquipamento == this.enderecoOrigemDestinoInput.COD_TipoEquipamento);
            }, error => {
              this.notifyService.HttpError('Atenção', error);
            })
      }

      this.modalidadecreditoD0 = this.enderecoOrigemDestinoInput.VL_ModalidadeCredito == 0;
      this.modalidadecreditoD1 = this.enderecoOrigemDestinoInput.VL_ModalidadeCredito == 1;
      this.flgImpressaoEnderecoDestino = this.enderecoOrigemDestinoInput.FLG_ImpressaoEnderecoDestino;

      // if(this.enderecoOrigemDestinoInput.DT_Base) {
      //   var datePipe = new DatePipe('pt-br');
      //   (<HTMLInputElement>document.getElementById('baseDateTime')).value = this.enderecoOrigemDestinoInput.DT_Base.getMonth.toString();
      // }

    }else{
      //this.enderecoOrigemDestinoInput.DT_Base = new Date(Date.now());
    }
  }

  //------------------------------------------- OUTROS :

  collapse() {
    this.collapseUpload = !this.collapseUpload;
  }

  downloadWorksheet(compusafe: boolean) {
    let observable = this.enderecoOrigemDestinoService.downloadModelo(compusafe);
    observable.subscribe(resultado => {
      console.log(resultado);
    });
  }

  incomingfile(event) {
    this.file = event.target.files[0];
    this.enderecoOrigemDestinoImportacao.QuantidadeTotal = 0;
    this.enderecoOrigemDestinoImportacao.TotalImportado = 0;
    this.enderecoOrigemDestinoImportacao.Mensagens = [];

    if (this.file) {
      this.fileName = this.file.name.substring(0,45);
      this.upload();
    } else {
      this.fileName = '';
    }

    this.file = null;
  }

  upload() {
    const fileReader = new FileReader();
      fileReader.onload = (e) => {
        this.arrayBuffer = fileReader.result;
        const data = new Uint8Array(this.arrayBuffer);
        const arr = new Array();
        for (let i = 0; i != data.length; ++i) {
          arr[i] = String.fromCharCode(data[i]);
        }
        const bstr = arr.join('');
        const workbook = XLSX.read(bstr, { type: 'binary' } );
        const firstSheeName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheeName];
        this.worksheet = XLSX.utils.sheet_to_json(worksheet, { raw: true } );
        if (this.worksheet) {
          this.enderecoOrigemDestinoImportacao.QuantidadeTotal = this.worksheet.length;
          this.worksheetIsValid(this.worksheet);
          this.worksheetToModel(this.worksheet.filter(row => row['VALIDO']));
          this.enderecoOrigemDestinoService.importar(this.enderecosOrigemDestinoExcel)
            .subscribe((resultado) => {
              this.notifyService.Info('', 'Importação Finalizada');
              if (resultado) {
                this.enderecoOrigemDestinoImportacao.TotalImportado = resultado.TotalImportado;
                _.forEach(resultado.Mensagens, (mensagem) => {
                  const enderecoOrigemDestinoAdicionado = this.enderecosOrigemDestinoExcel.filter(
                    enderecoOrigemDestino => enderecoOrigemDestino.Nom_Ponto === mensagem.NomePonto
                    && mensagem.Importado);
                  if (enderecoOrigemDestinoAdicionado.length > 0) {
                    this.onEnderecoOrigemDestinoAdicionado.emit(enderecoOrigemDestinoAdicionado[0]);
                  }
                  this.enderecoOrigemDestinoImportacao.Mensagens.push(mensagem);
                })
              }
            }, (error) => {
              this.notifyService.HttpError('Atenção', error);
            });
        }
      }
    fileReader.readAsArrayBuffer(this.file);
  }

  worksheetToModel(worksheet: any) {
    this.enderecosOrigemDestinoExcel = [];
    _.forEach(worksheet, (row) => {
      const enderecoOrigemDestinoExcel = new EnderecoOrigemDestinoInput();
      enderecoOrigemDestinoExcel.COD_PontoAtendimento = this.pai_ID_PontoAtendimento;
      enderecoOrigemDestinoExcel.Nom_Ponto = row['NOME DO PONTO*'];
      enderecoOrigemDestinoExcel.Nom_Abvd_Filial = this.removeAccent(row['FILIAL BRINKS*']);
      if (row['ORIGEM: CNPJ*'].length > 14) {
        enderecoOrigemDestinoExcel.Doc_CnpjOrigem = row['ORIGEM: CNPJ*'].substring(1);
      } else {
        enderecoOrigemDestinoExcel.Doc_CnpjOrigem = row['ORIGEM: CNPJ*'];
      }

      if (row['ORIGEM: EXISTE CEP']) {
        enderecoOrigemDestinoExcel.End_CepOrigem = row['ORIGEM: CEP'];
        enderecoOrigemDestinoExcel.End_NumeroOrigem = row['ORIGEM: NR ENDEREÇO'];
      }

      if (row['ORIGEM: EXISTE ENDEREÇO']) {
        enderecoOrigemDestinoExcel.End_Origem = row['ORIGEM: LOGRADOURO'].toUpperCase();
        enderecoOrigemDestinoExcel.End_BairroOrigem = row['ORIGEM: BAIRRO'].toUpperCase();
        enderecoOrigemDestinoExcel.Cid_Origem = row['ORIGEM: CIDADE'].toUpperCase();
        enderecoOrigemDestinoExcel.End_EstadoOrigem = row['ORIGEM: ESTADO'].toUpperCase();
        enderecoOrigemDestinoExcel.End_NumeroOrigem = row['ORIGEM: NR ENDEREÇO'];
      }

      enderecoOrigemDestinoExcel.Nom_Banco = row['BANCO TESOURARIA'];
      enderecoOrigemDestinoExcel.COD_Agencia = row['AGÊNCIA'];
      enderecoOrigemDestinoExcel.NR_Conta = row['CONTA'];

      if (this.tipoPropostaInput.COD_CategoriaTipoProposta) {
        enderecoOrigemDestinoExcel.Nom_TipoEquipamento = row['MODELO DO COFRE*'];
        enderecoOrigemDestinoExcel.VL_LimiteDiurno = row['LIMITE DIURNO*'];
        enderecoOrigemDestinoExcel.VL_LimiteNoturno = row['LIMITE NOTURNO*'];
        enderecoOrigemDestinoExcel.NR_TempoContratoCofre = row['TEMPO CONTRATO COFRE'];
      }

      if (row['MODALIDADE DE CRÉDITO']) {
        enderecoOrigemDestinoExcel.VL_ModalidadeCredito = row['MODALIDADE DE CRÉDITO'] === 'D+0' ? 0 : 1;
      }

      if (!row['DESTINO FILIAL']) {
        if (row['DESTINO: CNPJ'].length > 14) {
          enderecoOrigemDestinoExcel.Doc_CnpjDestino = row['DESTINO: CNPJ'].substring(1);
        } else {
          enderecoOrigemDestinoExcel.Doc_CnpjDestino = row['DESTINO: CNPJ'];
        }
        enderecoOrigemDestinoExcel.End_CepDestino = row['DESTINO: CEP'];
        enderecoOrigemDestinoExcel.End_NumeroDestino = row['DESTINO: NR ENDEREÇO'];

        if (row['DESTINO: EXISTE CEP']) {
          enderecoOrigemDestinoExcel.End_CepDestino = row['DESTINO: CEP'];
          enderecoOrigemDestinoExcel.End_NumeroDestino = row['DESTINO: NR ENDEREÇO'];
        }

        if (row['DESTINO: EXISTE ENDEREÇO']) {
          enderecoOrigemDestinoExcel.End_Destino = row['DESTINO: LOGRADOURO'].toUpperCase();
          enderecoOrigemDestinoExcel.End_BairroDestino = row['DESTINO: BAIRRO'].toUpperCase();
          enderecoOrigemDestinoExcel.Cid_Destino = row['DESTINO: CIDADE'].toUpperCase();
          enderecoOrigemDestinoExcel.End_EstadoDestino = row['DESTINO: ESTADO'].toUpperCase();
          enderecoOrigemDestinoExcel.End_NumeroDestino = row['DESTINO: NR ENDEREÇO'];
        }

      }
      if ((/^([0-2][0-9]|(3)[0-1])(\/)(((0)[0-9])|((1)[0-2]))(\/)\d{4}$/.test(row['DATA BASE*']))) {
        const date = row['DATA BASE*'].split('/');
        enderecoOrigemDestinoExcel.DT_Base = new Date(date[2], date[1] - 1, date[0]);
      } else {
        enderecoOrigemDestinoExcel.DT_Base = this.excelDateToJSDate(row['DATA BASE*']);
      }

      this.enderecosOrigemDestinoExcel.push(enderecoOrigemDestinoExcel);
    });
  }

  worksheetIsValid(worksheet: any) {
    _.forEach(worksheet, (row) => {
      let valid: boolean = true;
      const line = 'Linha ' + (row.__rowNum__ + 1);

      if (!row['NOME DO PONTO*']) {
        valid = false;
        this.enderecoOrigemDestinoImportacao.Mensagens.push(
            {
              NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
              Descricao: 'Nome do Ponto é obrigatório',
              Erro: true,
            },
          );
      } else {
        const pontoAtendimentoExistente = this.pontosAtendimento.filter(
          pontoAtendimento => pontoAtendimento.Nom_Ponto === row['NOME DO PONTO*']
        );

        if (pontoAtendimentoExistente.length > 0) {
          valid = false;
          this.enderecoOrigemDestinoImportacao.Mensagens.push(
            {
              NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
              Descricao: 'Já existe um Ponto de Atendimento cadastrado com esse nome',
              Erro: true,
            },
          );
        }
      }

      if (_.filter(
          this.worksheet,
          (pointService) => pointService['NOME DO PONTO'] === row['NOME DO PONTO*']).length > 1) {
        valid = false;
        this.enderecoOrigemDestinoImportacao.Mensagens.push(
          {
            NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
            Descricao: 'Não é permitido criar Pontos de Atendimento com nomes duplicados',
            Erro: true,
          },
        );
      }

      if (!row['FILIAL BRINKS*']) {
        valid = false;
        this.enderecoOrigemDestinoImportacao.Mensagens.push(
          {
            NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
            Descricao: '[COLUNA FILIAL BRINKS*] - Sigla da Filial Brinks é obrigatória',
            Erro: true,
          },
        );
      }

      if (!row['DATA BASE*']) {
        valid = false;
        this.enderecoOrigemDestinoImportacao.Mensagens.push(
          {
            NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
            Descricao: '[COLUNA DATA BASE*] - Data Base é obrigatória',
            Erro: true,
          },
        );
      } else {
        if (!(/^([0-2][0-9]|(3)[0-1])(\/)(((0)[0-9])|((1)[0-2]))(\/)\d{4}$/.test(row['DATA BASE*']))) {
          if (!this.excelDateToJSDate(row['DATA BASE*'])) {
            valid = false;
            this.enderecoOrigemDestinoImportacao.Mensagens.push(
              {
                NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
                Descricao: '[COLUNA DATA BASE*] - Digite uma data válida em Data Base',
                Erro: true,
              },
            );
          }
        }
      }

      if (row['MODALIDADE DE CRÉDITO']
        && row['MODALIDADE DE CRÉDITO'] !== 'D+0'
        && row['MODALIDADE DE CRÉDITO'] !== 'D+1') {
        valid = false;
        this.enderecoOrigemDestinoImportacao.Mensagens.push(
          {
            NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
            Descricao: '[COLUNA MODALIDADE DE CRÉDITO] - Modalidade de Crédito deve ser D+0 ou D+1',
            Erro: true,
          },
        );
      }

      if (this.tipoPropostaInput.COD_CategoriaTipoProposta) {
        if (!row['MODELO DO COFRE*']) {
          valid = false;
          this.enderecoOrigemDestinoImportacao.Mensagens.push(
            {
              NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
              Descricao: '[COLUNA MODELO DO COFRE*] - Modelo do Cofre é obrigatório',
              Erro: true,
            },
          );
        }
        if (!/^\d+$/.test(row['LIMITE DIURNO*'])) {
          valid = false;
          this.enderecoOrigemDestinoImportacao.Mensagens.push(
            {
              NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
              Descricao: '[COLUNA LIMITE DIURNO*] - Digite apenas números no Limite Diurno',
              Erro: true,
            },
          );
        } else {
          if (+row['LIMITE DIURNO*'] <= 0) {
            valid = false;
            this.enderecoOrigemDestinoImportacao.Mensagens.push(
              {
                NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
                Descricao: '[COLUNA LIMITE DIURNO*] - Limite Diurno não pode ser menor ou igual a 0',
                Erro: true,
              },
            );
          }
        }
        if (!/^\d+$/.test(row['LIMITE NOTURNO*'])) {
          valid = false;
          this.enderecoOrigemDestinoImportacao.Mensagens.push(
            {
              NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
              Descricao: '[COLUNA LIMITE NOTURNO*] - Digite apenas números no Limite Noturno',
              Erro: true,
            },
          );
        } else {
          if (+row['LIMITE NOTURNO*'] <= 0) {
            valid = false;
            this.enderecoOrigemDestinoImportacao.Mensagens.push(
              {
                NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
                Descricao: '[COLUNA LIMITE NOTURNO*] - Limite Noturno não pode ser menor ou igual a 0',
                Erro: true,
              },
            );
          }
        }

        if (row['TEMPO CONTRATO COFRE']) {
          if (!/^\d+$/.test(row['TEMPO CONTRATO COFRE'])) {
            valid = false;
            this.enderecoOrigemDestinoImportacao.Mensagens.push(
              {
                NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
                Descricao: '[COLUNA TEMPO CONTRATO COFRE] - Digite apenas números no Tempo de Contrato do Cofre',
                Erro: true,
              },
            );
          }
        }
      }

      if (!row['ORIGEM: CNPJ*']) {
        valid = false;
        this.enderecoOrigemDestinoImportacao.Mensagens.push(
          {
            NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
            Descricao: '[COLUNA ORIGEM: CNPJ*] - CNPJ do Endereço de Origem é obrigatório',
            Erro: true,
          },
        );
      } else {
        if (!/^\d+$/.test(row['ORIGEM: CNPJ*'])) {
          valid = false;
          this.enderecoOrigemDestinoImportacao.Mensagens.push(
            {
              NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
              Descricao: '[COLUNA ORIGEM: CNPJ*] - Digite apenas números no CNPJ de Origem',
              Erro: true,
            },
          );
        }
      }

      if (row['ORIGEM: CEP']) {
        row['ORIGEM: EXISTE CEP'] = true;

        if (!/^\d+$/.test(row['ORIGEM: CEP'])) {
          valid = false;
          this.enderecoOrigemDestinoImportacao.Mensagens.push(
            {
              NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
              Descricao: '[COLUNA ORIGEM: CEP] - Digite apenas números no CEP de Origem',
              Erro: true,
            },
          );
        }

        if (!(/^\d{8}$/.test(row['ORIGEM: CEP']))) {
          valid = false;
          this.enderecoOrigemDestinoImportacao.Mensagens.push(
            {
              NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
              Descricao: '[COLUNA ORIGEM: CEP] - CEP de Origem informado deve possuir 8 dígitos',
              Erro: true,
            },
          );
        }
      } else {
        if (row['ORIGEM: LOGRADOURO']
          && row['ORIGEM: BAIRRO']
          && row['ORIGEM: CIDADE']
          && row['ORIGEM: ESTADO']) {
            row['ORIGEM: EXISTE ENDEREÇO'] = true;

            if (!(/^(?=[\S\s]{1,255}$)[\S\s]*/.test(row['ORIGEM: LOGRADOURO']))) {
              valid = false;
              this.enderecoOrigemDestinoImportacao.Mensagens.push(
                {
                  NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
                  Descricao: '[COLUNA ORIGEM: LOGRADOURO] - Logradouro deve ter no máximo 255 caracteres',
                  Erro: true,
                },
              );
            }

            if (!(/^(?=[\S\s]{1,100}$)[\S\s]*/.test(row['ORIGEM: BAIRRO']))) {
              valid = false;
              this.enderecoOrigemDestinoImportacao.Mensagens.push(
                {
                  NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
                  Descricao: '[COLUNA ORIGEM: BAIRRO] - Bairro de Origem deve ter no máximo 100 caracteres',
                  Erro: true,
                },
              );
            }

            if (!(/^(?=[\S\s]{1,50}$)[\S\s]*/.test(row['ORIGEM: CIDADE']))) {
              valid = false;
              this.enderecoOrigemDestinoImportacao.Mensagens.push(
                {
                  NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
                  Descricao: '[COLUNA ORIGEM: CIDADE] - Cidade de Origem deve ter no máximo 50 caracteres',
                  Erro: true,
                },
              );
            }

            if (!(/^[A-Za-z]{2}/.test(row['ORIGEM: ESTADO']))) {
              valid = false;
              this.enderecoOrigemDestinoImportacao.Mensagens.push(
                {
                  NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
                  Descricao: '[COLUNA ORIGEM: ESTADO] - Sigla do Estado de Origem informado deve possuir 2 caracteres',
                  Erro: true,
                },
              );
            }
        }
      }

      if (!row['ORIGEM: NR ENDEREÇO'] && (row['ORIGEM: EXISTE CEP'] || row['ORIGEM: EXISTE ENDEREÇO'])) {
        valid = false;
        this.enderecoOrigemDestinoImportacao.Mensagens.push(
          {
            NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
            Descricao: '[COLUNA ORIGEM: NR ENDEREÇO] - Número do Endereço de Origem é obrigatório',
            Erro: true,
          },
        );
      }

      if (!row['ORIGEM: EXISTE CEP'] && !row['ORIGEM: EXISTE ENDEREÇO']) {
        this.enderecoOrigemDestinoImportacao.Mensagens.push(
          {
            NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
            Descricao: `Por não existir CEP ou Endereço completo,
            o Endereço de Origem será inserido a partir do CNPJ de Origem`,
          },
        );
      }

      if (!row['DESTINO: CNPJ']) {
        row['DESTINO FILIAL'] = true;
        this.enderecoOrigemDestinoImportacao.Mensagens.push(
          {
            NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
            Descricao: 'Por não ter sido informado o CNPJ do Destino, serão utilizados os dados da Filial como Destino',
          },
        );
      } else {
        if (!/^\d+$/.test(row['DESTINO: CNPJ'])) {
          valid = false;
          this.enderecoOrigemDestinoImportacao.Mensagens.push(
            {
              NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
              Descricao: '[COLUNA DESTINO: CNPJ] - Digite apenas números no CNPJ de Destino',
              Erro: true,
            },
          );
        }

        if (row['DESTINO: CEP']) {
          row['DESTINO: EXISTE CEP'] = true;

          if (!/^\d+$/.test(row['DESTINO: CEP'])) {
            valid = false;
            this.enderecoOrigemDestinoImportacao.Mensagens.push(
              {
                NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
                Descricao: '[COLUNA DESTINO: CEP] - Digite apenas números no CEP de Destino',
                Erro: true,
              },
            );
          }

          if (!(/^\d{8}$/.test(row['DESTINO: CEP']))) {
            valid = false;
            this.enderecoOrigemDestinoImportacao.Mensagens.push(
              {
                NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
                Descricao: '[COLUNA DESTINO: CEP] - CEP de Destino informado deve possuir 8 dígitos',
                Erro: true,
              },
            );
          }
        } else {
          if (row['DESTINO: LOGRADOURO']
            && row['DESTINO: BAIRRO']
            && row['DESTINO: CIDADE']
            && row['DESTINO: ESTADO']) {
              row['DESTINO: EXISTE ENDEREÇO'] = true;

              if (!(/^(?=[\S\s]{1,255}$)[\S\s]*/.test(row['DESTINO: LOGRADOURO']))) {
                valid = false;
                this.enderecoOrigemDestinoImportacao.Mensagens.push(
                  {
                    NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
                    Descricao: '[COLUNA DESTINO: LOGRADOURO] - Logradouro deve ter no máximo 255 caracteres',
                    Erro: true,
                  },
                );
              }

              if (!(/^(?=[\S\s]{1,100}$)[\S\s]*/.test(row['DESTINO: BAIRRO']))) {
                valid = false;
                this.enderecoOrigemDestinoImportacao.Mensagens.push(
                  {
                    NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
                    Descricao: '[COLUNA DESTINO: BAIRRO] - Bairro de Destino deve ter no máximo 100 caracteres',
                    Erro: true,
                  },
                );
              }

              if (!(/^(?=[\S\s]{1,50}$)[\S\s]*/.test(row['DESTINO: CIDADE']))) {
                valid = false;
                this.enderecoOrigemDestinoImportacao.Mensagens.push(
                  {
                    NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
                    Descricao: '[COLUNA DESTINO: CIDADE] - Cidade de Destino deve ter no máximo 50 caracteres',
                    Erro: true,
                  },
                );
              }

              if (!(/^[A-Za-z]{2}/.test(row['DESTINO: ESTADO']))) {
                valid = false;
                this.enderecoOrigemDestinoImportacao.Mensagens.push(
                  {
                    NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
                    Descricao: `[COLUNA DESTINO: ESTADO] -
                    Sigla do Estado de Destino informado deve possuir 2 caracteres`,
                    Erro: true,
                  },
                );
              }
          }
        }

        if (!row['DESTINO: NR ENDEREÇO'] && (row['DESTINO: EXISTE CEP'] || row['DESTINO: EXISTE ENDEREÇO'])) {
          valid = false;
          this.enderecoOrigemDestinoImportacao.Mensagens.push(
            {
              NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
              Descricao: '[COLUNA DESTINO: NR ENDEREÇO] - Número do Endereço de Destino é obrigatório',
              Erro: true,
            },
          );
        }

        if (!row['DESTINO: EXISTE CEP'] && !row['DESTINO: EXISTE ENDEREÇO']) {
          this.enderecoOrigemDestinoImportacao.Mensagens.push(
            {
              NomePonto: row['NOME DO PONTO*'] ? row['NOME DO PONTO*'] : line,
              Descricao: `Por não existir CEP ou Endereço completo,
              o Endereço de Destino será inserido a partir do CNPJ de Destino`,
            },
          );
        }
      }

      row['VALIDO'] = valid;
      },
    );
  }

  excelDateToJSDate(serial) {
    const utcDays = Math.floor(serial - 25569);
    const utcValue = utcDays * 86400;
    const dateInfo = new Date(utcValue * 1000);

    const fractionalDay = serial - Math.floor(serial) + 0.0000001;

    let totalSeconds = Math.floor(86400 * fractionalDay);

    const seconds = totalSeconds % 60;

    totalSeconds -= seconds;

    const hours = Math.floor(totalSeconds / (60 * 60));
    const minutes = Math.floor(totalSeconds / 60) % 60;

    return new Date(dateInfo.getFullYear(), dateInfo.getMonth(), dateInfo.getDate() + 1, hours, minutes, seconds);
 }

  removeAccent(text: string) {
      text = text.toLowerCase();
      text = text.replace(new RegExp('[ÁÀÂÃ]', 'gi'), 'a');
      text = text.replace(new RegExp('[ÉÈÊ]', 'gi'), 'e');
      text = text.replace(new RegExp('[ÍÌÎ]', 'gi'), 'i');
      text = text.replace(new RegExp('[ÓÒÔÕ]', 'gi'), 'o');
      text = text.replace(new RegExp('[ÚÙÛ]', 'gi'), 'u');
      text = text.replace(new RegExp('[Ç]', 'gi'), 'c');
      return text;
  }

  public obterEnderecoOrigemDestino(Id_EnderecoOrigemDestino: number): void {
    let observable = this.pontoAtendimentoOrigemDestinoService.obter(
      Id_EnderecoOrigemDestino
    );
    observable.subscribe(resultado => {
      this.enderecoOrigemDestinoInput = resultado;
      //this.obterServico(resultado.COD_Servico);
    });
  }

  public fechar(): void {
    this.modalRef.close();
  }

  // preenche o combo EntidadeTipoEndereco
  private ObterEntidadeTipoEnderecos(): void {
    let filtro = new Dados<EntidadeTipoEnderecoInput>();
    filtro.Opcoes = {
      NomeCampo: 'DES_EntidadeTpEndereco',
      PaginaAtual: 1,
      SentidoOrdenacao: Ordenacao.ASC,
      TamanhoPagina: 255
    };
    let observable = this.entidadeTipoEnderecoService.selecionar(filtro);
    observable.subscribe(resultado => {
      this.entidadeTipoEnderecos_o = resultado.Dados;
      this.entidadeTipoEnderecos_d = resultado.Dados;

      this.enderecoOrigemDestinoInput.Cod_EntidadeTpEnderecoOrig =
        this.enderecoOrigemDestinoInput.Cod_EntidadeTpEnderecoOrig ||
        _.find(this.entidadeTipoEnderecos_o, {
          DES_EntidadeTpEndereco: 'Federal'
        }).ID_EntidadeTpEndereco;

      this.enderecoOrigemDestinoInput.Cod_EntidadeTpEnderecoDest =
        this.enderecoOrigemDestinoInput.Cod_EntidadeTpEnderecoDest ||
        _.find(this.entidadeTipoEnderecos_o, {
          DES_EntidadeTpEndereco: 'Federal'
        }).ID_EntidadeTpEndereco;

      if (this._origemVazia()) this._contratanteOrigem('1');

      this._contratanteDestino('1');
    });
  }

  private validarOrigemDestino(): boolean {
    let valido: boolean = true;

    //Nom_Ponto
    if (
      !this.enderecoOrigemDestinoInput.Nom_Ponto ||
      !this.enderecoOrigemDestinoInput.Nom_Ponto.trim()
    ) {
      valido = false;
      this.notifyService.Error('Atenção', 'Campo Nome do Ponto é obrigatório.');
    } else if (this.enderecoOrigemDestinoInput.Nom_Ponto.length > 100) {
      valido = false;
      this.notifyService.Error('Atenção', 'Nome do Ponto inválido.');
    }

    if (!this.filialViewModelPai) {
      valido = false;
      this.notifyService.Error('Atenção', 'Escolha uma filial.');
    }

    if (!this.enderecoOrigemDestinoInput.DT_Base) {
      valido = false;
      this.notifyService.Error('Atenção', 'Digite uma Data Base.');
    }

    const ano = this.enderecoOrigemDestinoInput.DT_Base ? this.enderecoOrigemDestinoInput.DT_Base.getFullYear() : 0;

    if (ano < 1900 || ano > 2999) {
      valido = false;
      this.notifyService.Error('Atenção', 'Digite uma Data Base Válida.');
    }

    // verificacao agencia

    if (this.entidadeAgenciaViewModel != undefined){
      if (this.entidadeAgenciaViewModel.ID_EntidadeAgencia == undefined){
        this.enderecoOrigemDestinoInput.COD_EntidadeAgencia =  (<HTMLInputElement>document.getElementById('nom_entidadeAgencia')).value ;
      }else{
        this.enderecoOrigemDestinoInput.COD_EntidadeAgencia = String(this.entidadeAgenciaViewModel.ID_EntidadeAgencia);
      }
    }else{
      this.enderecoOrigemDestinoInput.COD_EntidadeAgencia =  (<HTMLInputElement>document.getElementById('nom_entidadeAgencia')).value ;
    }

    if(isNaN(Number(this.enderecoOrigemDestinoInput.COD_EntidadeAgencia))){
      valido = false;
      this.notifyService.Error('Atenção', 'Agência deve conter apenas números.');
      this.enderecoOrigemDestinoInput.COD_EntidadeAgencia = null;
    }else{
      // verifica numero da agencia muito grande para nao estourar no banco
      if (Number(this.enderecoOrigemDestinoInput.COD_EntidadeAgencia.trim)>9999){
        valido = false;
        this.notifyService.Error('Atenção', 'Número da agência não deve ser maior que 9999 (4 digitos).');
        this.enderecoOrigemDestinoInput.COD_EntidadeAgencia = null;
      }
    }

    if(this.tipoPropostaInput.COD_CategoriaTipoProposta) {
      valido = valido && this.validarCamposCompusafe();
    }

    //----- ORIGEM

    //tipo do ponto
    if (!this.enderecoOrigemDestinoInput.Cod_EntidadeTpEnderecoOrig) {
      valido = false;
      this.notifyService.Error(
        'Atenção',
        'Escolha um tipo de ponto válido na Origem.'
      );
    }

    //Doc_CnpjOrigem
    if (
      !this.enderecoOrigemDestinoInput.Doc_CnpjOrigem ||
      this.enderecoOrigemDestinoInput.Doc_CnpjOrigem == ''
    ) {
      valido = false;
      this.notifyService.Error('Atenção', 'Campo Cnpj Origem é obrigatório.');
    } else if (this.enderecoOrigemDestinoInput.Doc_CnpjOrigem.length > 18) {
      valido = false;
      this.notifyService.Error('Atenção', 'Cnpj Origem inválido.');
    }

    //End_CepOrigem
    if (
      !this.enderecoOrigemDestinoInput.End_CepOrigem ||
      this.enderecoOrigemDestinoInput.End_CepOrigem == ''
    ) {
      valido = false;
      this.notifyService.Error('Atenção', 'Campo Cep Origem é obrigatório.');
    } else if (this.enderecoOrigemDestinoInput.End_CepOrigem.length > 8) {
      valido = false;
      this.notifyService.Error('Atenção', 'Cep Origem inválido.');
    }

    //End_BairroOrigem
    if (
      !this.enderecoOrigemDestinoInput.End_BairroOrigem ||
      this.enderecoOrigemDestinoInput.End_BairroOrigem == ''
    ) {
      valido = false;
      this.notifyService.Error('Atenção', 'Campo Bairro Origem é obrigatório.');
    } else if (this.enderecoOrigemDestinoInput.End_BairroOrigem.length > 100) {
      valido = false;
      this.notifyService.Error('Atenção', 'Bairro Origem inválido.');
    }

    //Cid_Origem
    if (
      !this.enderecoOrigemDestinoInput.Cid_Origem ||
      this.enderecoOrigemDestinoInput.Cid_Origem == ''
    ) {
      valido = false;
      this.notifyService.Error('Atenção', 'Campo Cidade Origem é obrigatório.');
    } else if (this.enderecoOrigemDestinoInput.Cid_Origem.length > 50) {
      valido = false;
      this.notifyService.Error('Atenção', 'Cidade Origem inválido.');
    }

    //End_EstadoOrigem
    if (
      !this.enderecoOrigemDestinoInput.End_EstadoOrigem ||
      this.enderecoOrigemDestinoInput.End_EstadoOrigem == ''
    ) {
      valido = false;
      this.notifyService.Error('Atenção', 'Campo Estado Origem é obrigatório.');
    } else if (this.enderecoOrigemDestinoInput.End_EstadoOrigem.length > 50) {
      valido = false;
      this.notifyService.Error('Atenção', 'Estado Origem inválido.');
    }

    //End_Origem
    if (
      !this.enderecoOrigemDestinoInput.End_Origem ||
      this.enderecoOrigemDestinoInput.End_Origem == ''
    ) {
      valido = false;
      this.notifyService.Error(
        'Atenção',
        'Campo Endereco Origem é obrigatório.'
      );
    } else if (this.enderecoOrigemDestinoInput.End_Origem.length > 255) {
      valido = false;
      this.notifyService.Error('Atenção', 'Endereco Origem inválido.');
    }

    //End_NumeroOrigem
    if (
      !this.enderecoOrigemDestinoInput.End_NumeroOrigem ||
      this.enderecoOrigemDestinoInput.End_NumeroOrigem == ''
    ) {
      valido = false;
      this.notifyService.Error('Atenção', 'Campo Numero Origem é obrigatório.');
    } else if (this.enderecoOrigemDestinoInput.End_NumeroOrigem.length > 15) {
      valido = false;
      this.notifyService.Error('Atenção', 'Numero Origem inválido.');
    }

    //Compl_Origem

    //Nom_RazaoSocialOrig
    if (
      !this.enderecoOrigemDestinoInput.Nom_RazaoSocialOrig ||
      this.enderecoOrigemDestinoInput.Nom_RazaoSocialOrig == ''
    ) {
      valido = false;
      this.notifyService.Error(
        'Atenção',
        'Campo Razao Social Origem é obrigatório.'
      );
    } else if (
      this.enderecoOrigemDestinoInput.Nom_RazaoSocialOrig.length > 300
    ) {
      valido = false;
      this.notifyService.Error('Atenção', 'Razao Social Origem inválido.');
    }

    //----- DESTINO

    //tipo do ponto
    if (!this.enderecoOrigemDestinoInput.Cod_EntidadeTpEnderecoDest) {
      valido = false;
      this.notifyService.Error(
        'Atenção',
        'Escolha um tipo de ponto válido no destino.'
      );
    }

    //Doc_CnpjDestino
    if (
      !this.enderecoOrigemDestinoInput.Doc_CnpjDestino ||
      this.enderecoOrigemDestinoInput.Doc_CnpjDestino == ''
    ) {
      valido = false;
      this.notifyService.Error('Atenção', 'Campo Cnpj Destino é obrigatório.');
    } else if (this.enderecoOrigemDestinoInput.Doc_CnpjDestino.length > 18) {
      valido = false;
      this.notifyService.Error('Atenção', 'Cnpj Destino inválido.');
    }

    //End_CepDestino
    if (
      !this.enderecoOrigemDestinoInput.End_CepDestino ||
      this.enderecoOrigemDestinoInput.End_CepDestino == ''
    ) {
      valido = false;
      this.notifyService.Error('Atenção', 'Campo Cep Destino é obrigatório.');
    } else if (this.enderecoOrigemDestinoInput.End_CepDestino.length > 8) {
      valido = false;
      this.notifyService.Error('Atenção', 'Cep Destino inválido.');
    }

    //End_BairroDestino
    if (
      !this.enderecoOrigemDestinoInput.End_BairroDestino ||
      this.enderecoOrigemDestinoInput.End_BairroDestino == ''
    ) {
      valido = false;
      this.notifyService.Error(
        'Atenção',
        'Campo Bairro Destino é obrigatório.'
      );
    } else if (this.enderecoOrigemDestinoInput.End_BairroDestino.length > 100) {
      valido = false;
      this.notifyService.Error('Atenção', 'Bairro Destino inválido.');
    }

    //Cid_Destino
    if (
      !this.enderecoOrigemDestinoInput.Cid_Destino ||
      this.enderecoOrigemDestinoInput.Cid_Destino == ''
    ) {
      valido = false;
      this.notifyService.Error(
        'Atenção',
        'Campo Cidade Destino é obrigatório.'
      );
    } else if (this.enderecoOrigemDestinoInput.Cid_Destino.length > 50) {
      valido = false;
      this.notifyService.Error('Atenção', 'Cidade Destino inválido.');
    }

    //End_EstadoDestino
    if (
      !this.enderecoOrigemDestinoInput.End_EstadoDestino ||
      this.enderecoOrigemDestinoInput.End_EstadoDestino == ''
    ) {
      valido = false;
      this.notifyService.Error(
        'Atenção',
        'Campo Estado Destino é obrigatório.'
      );
    } else if (this.enderecoOrigemDestinoInput.End_EstadoDestino.length > 50) {
      valido = false;
      this.notifyService.Error('Atenção', 'Estado Destino inválido.');
    }

    //End_Destino
    if (
      !this.enderecoOrigemDestinoInput.End_Destino ||
      this.enderecoOrigemDestinoInput.End_Destino == ''
    ) {
      valido = false;
      this.notifyService.Error(
        'Atenção',
        'Campo Endereco Destino é obrigatório.'
      );
    } else if (this.enderecoOrigemDestinoInput.End_Destino.length > 255) {
      valido = false;
      this.notifyService.Error('Atenção', 'Endereco Destino inválido.');
    }

    //End_NumeroDestino
    if (
      !this.enderecoOrigemDestinoInput.End_NumeroDestino ||
      this.enderecoOrigemDestinoInput.End_NumeroDestino == ''
    ) {
      valido = false;
      this.notifyService.Error(
        'Atenção',
        'Campo Numero Destino é obrigatório.'
      );
    } else if (this.enderecoOrigemDestinoInput.End_NumeroDestino.length > 15) {
      valido = false;
      this.notifyService.Error('Atenção', 'Numero Destino inválido.');
    }

    //Compl_Destino

    //Nom_RazaoSocialDest
    if (
      !this.enderecoOrigemDestinoInput.Nom_RazaoSocialDest ||
      this.enderecoOrigemDestinoInput.Nom_RazaoSocialDest == ''
    ) {
      valido = false;
      this.notifyService.Error(
        'Atenção',
        'Campo Razao Social Destino é obrigatório.'
      );
    } else if (
      this.enderecoOrigemDestinoInput.Nom_RazaoSocialDest.length > 300
    ) {
      valido = false;
      this.notifyService.Error('Atenção', 'Razao Social Destino inválido.');
    }

    return valido;
  }
  validarCamposCompusafe(): boolean {
    let valido = true;

    if(!this.tipoEquipamentoViewModel || !this.tipoEquipamentoViewModel.Id_TpEquipamento) {
      valido = false;
      this.notifyService.Error('Atenção', 'Modelo do Cofre inválido.');
    }

    if(!this.enderecoOrigemDestinoInput.VL_LimiteDiurno || this.enderecoOrigemDestinoInput.VL_LimiteDiurno <= 0) {
      valido = false;
      this.notifyService.Error('Atenção', 'Limite Diurno inválido.');
    }

    if(!this.enderecoOrigemDestinoInput.VL_LimiteNoturno || this.enderecoOrigemDestinoInput.VL_LimiteNoturno <= 0) {
      valido = false;
      this.notifyService.Error('Atenção', 'Limite Noturno inválido.');
    }

    if (this.enderecoOrigemDestinoInput.NR_TempoContratoCofre) {
      if (!/^\d+$/.test(this.enderecoOrigemDestinoInput.NR_TempoContratoCofre.toString())
      || this.enderecoOrigemDestinoInput.NR_TempoContratoCofre.toString().includes('e') ) {
        valido = false;
        this.notifyService.Error('Atenção', 'Digite apenas números referente aos meses de Tempo de Contrato do Cofre');
      }
    }

    return valido;
  }

  private salvarInclusaoAlteracaoOrigemDestino(): void {
    //validar
    if (this.validarOrigemDestino()) {
      let observablesFilho: Observable<any>[] = [];

      this.enderecoOrigemDestinoInput.FLG_Situacao = true;
      this.enderecoOrigemDestinoInput.COD_PontoAtendimento = this.pai_ID_PontoAtendimento;

      this.enderecoOrigemDestinoInput.COD_Regional = this.filialViewModelPai.Cod_Regional;
      this.enderecoOrigemDestinoInput.COD_Filial = this.filialViewModelPai.Cod_Filial;
      if (this.entidadeBancoViewModel)
        this.enderecoOrigemDestinoInput.COD_EntidadeBanco = this.entidadeBancoViewModel.ID_EntidadeBanco;
      else
      this.enderecoOrigemDestinoInput.COD_EntidadeBanco = null;

      if (this.entidadeAgenciaViewModel != null){
        if (this.entidadeAgenciaViewModel.ID_EntidadeAgencia == undefined)
          this.enderecoOrigemDestinoInput.COD_EntidadeAgencia =  (<HTMLInputElement>document.getElementById('nom_entidadeAgencia')).value ;
        else
          this.enderecoOrigemDestinoInput.COD_EntidadeAgencia = String(this.entidadeAgenciaViewModel.ID_EntidadeAgencia);
      }else{
        this.enderecoOrigemDestinoInput.COD_EntidadeAgencia =  (<HTMLInputElement>document.getElementById('nom_entidadeAgencia')).value ;
      }

      if (this.tipoEquipamentoViewModel)
        this.enderecoOrigemDestinoInput.COD_TipoEquipamento = this.tipoEquipamentoViewModel.Id_TpEquipamento;

      if (this.enderecoOrigemDestinoInput.ID_EnderecoOrigemDestino > 0) {
        //Altera
        let observableFilho = this.enderecoOrigemDestinoService.alterar(
          this.enderecoOrigemDestinoInput.ID_EnderecoOrigemDestino,
          this.enderecoOrigemDestinoInput
        );
        observableFilho.subscribe(
          resultado => {
            this.enderecoOrigemDestinoInput.ID_EnderecoOrigemDestino =
              resultado.ID_EnderecoOrigemDestino;
            observablesFilho.push(observableFilho);

            this.notifyService.Success(
              '',
              'Cadastro de Origem-Destino do Ponto realizado com sucesso.'
            );

            //diponibiliza ao emitter que vai ser ovido lá na "pagina pai"
            this.onEnderecoOrigemDestinoAdicionado.emit(
              this.enderecoOrigemDestinoInput
            );

            //limpeza
            this.enderecoOrigemDestinoInput.ID_EnderecoOrigemDestino = 0;
            this.enderecoOrigemDestinoInput.Nom_Ponto = '';

            if (
              this.enderecoOrigemDestinoInput.Doc_CnpjOrigem !=
              this.propostaInput.Doc_CnpjContratante
            ) {
              this.utilizaContratanteNaOrigem = true;
              this.textoContratanteNaOrigem = 'Utilizar Contratante';
            }
            //--------
            if (
              this.enderecoOrigemDestinoInput.Doc_CnpjDestino !=
              this.propostaInput.Doc_CnpjContratante
            ) {
              this.utilizaContratanteNoDestino = true;
              this.textoContratanteNoDestino = 'Utilizar Contratante';
            }
          },
          error => {
            this.notifyService.HttpError('Atenção', error);
          }
        );
      } else {
        //Insere
        let observableFilho = this.enderecoOrigemDestinoService.inserir(
          this.enderecoOrigemDestinoInput
          );
        observableFilho.subscribe(
          resultado => {
            this.enderecoOrigemDestinoInput.ID_EnderecoOrigemDestino =
              resultado.ID_EnderecoOrigemDestino;
            observablesFilho.push(observableFilho);

            this.notifyService.Success(
              '',
              'Cadastro de Origem-Destino do Ponto realizado com sucesso.'
            );

            //diponibiliza ao emitter que vai ser ovido lá na "pagina pai"
            this.onEnderecoOrigemDestinoAdicionado.emit(
              this.enderecoOrigemDestinoInput
            );

            //Limpeza
            this.enderecoOrigemDestinoInput.ID_EnderecoOrigemDestino = 0;
            this.enderecoOrigemDestinoInput.Nom_Ponto = '';

            if (
              this.enderecoOrigemDestinoInput.Doc_CnpjOrigem !=
              this.propostaInput.Doc_CnpjContratante
            ) {
              this.utilizaContratanteNaOrigem = true;
              this.textoContratanteNaOrigem = 'Utilizar Contratante';
            }
            //--------
            if (
              this.enderecoOrigemDestinoInput.Doc_CnpjDestino !=
              this.propostaInput.Doc_CnpjContratante
            ) {
              this.utilizaContratanteNoDestino = true;
              this.textoContratanteNoDestino = 'Utilizar Contratante';
            }

            this.escolheuFilialOrigem = false;
            this.escolheuFilialDestino = false;
          },
          error => {
            this.notifyService.HttpError('Atenção', error);
          }
        );
      }
    }
  }

  public ObterFiliais(): void {
    let filtro = new Dados<FilialInput>();
    filtro.Opcoes = {
      NomeCampo: 'Nom_Filial',
      PaginaAtual: 1,
      SentidoOrdenacao: Ordenacao.ASC,
      TamanhoPagina: 255
    };
    let observable = this.filialService.selecionar(filtro);
    observable.subscribe(resultado => {
      this.filiais = resultado.Dados;
    });
  }

  public teste() {}

  // ------------------------------------------- ORIGEM :
  public consultarCepOrigem(cep: number): void {
    if (cep) {
      if(cep.toString().length !== 8) {
        this.notifyService.Error('Atenção', 'CEP inválido');
        return;
      }
      let observable = this.bwsService.consultarCep(cep);
      observable.subscribe(
        resultado => {
          this.limparDadosEnderecoOrigem(false);
          if (resultado.Status == 1) {
            this.enderecoOrigemDestinoInput.End_BairroOrigem = resultado.Bairro;
            this.enderecoOrigemDestinoInput.End_Origem = resultado.Logradouro;
            this.enderecoOrigemDestinoInput.Cid_Origem = resultado.Cidade;
            this.enderecoOrigemDestinoInput.End_EstadoOrigem =
              resultado.UnidadeFederativa;
            this.enderecoOrigemDestinoInput.Compl_Origem =
              resultado.BairroComplemento;
            this.enderecoOrigemDestinoInput.End_NumeroOrigem = undefined;
          }
        },
        error => {
          this.limparDadosEnderecoOrigem(false);
        }
      );
    }
  }

  public limparDadosEnderecoOrigem(origemConsultaCnpj: boolean) {
    this.enderecoOrigemDestinoInput.End_BairroOrigem = undefined;
    if (origemConsultaCnpj) {
      this.enderecoOrigemDestinoInput.End_CepOrigem = undefined;
      this.enderecoOrigemDestinoInput.Nom_RazaoSocialOrig = undefined;
    }
    this.enderecoOrigemDestinoInput.End_Origem = undefined;
    this.enderecoOrigemDestinoInput.Cid_Origem = undefined;
    this.enderecoOrigemDestinoInput.End_NumeroOrigem = undefined;
    this.enderecoOrigemDestinoInput.Compl_Origem = undefined;
    this.enderecoOrigemDestinoInput.End_EstadoOrigem = undefined;
  }

  public consultarCnpjOrigem(cnpj: number): void {
    if (cnpj) {
      let observable = this.bwsService.consultarCnpj(cnpj);
      observable.subscribe(
        resultado => {
          this.limparDadosEnderecoOrigem(true);
          let status = resultado ? resultado.Status : BwSStatus.ErroInterno;
          switch (status) {
            case BwSStatus.Sucesso:
              {
                this.bloquearEdicaoRazaoSocialOrigem = true;
                this.enderecoOrigemDestinoInput.End_BairroOrigem =
                  resultado.Endereco.Bairro;
                if (resultado.Endereco.CEP)
                  this.enderecoOrigemDestinoInput.End_CepOrigem = _.padStart(
                    resultado.Endereco.CEP.toString(),
                    8,
                    '0'
                  );
                this.enderecoOrigemDestinoInput.Nom_RazaoSocialOrig =
                  resultado.RazaoSocial;
                this.enderecoOrigemDestinoInput.End_Origem =
                  resultado.Endereco.Logradouro;
                this.enderecoOrigemDestinoInput.Cid_Origem =
                  resultado.Endereco.Cidade;
                this.enderecoOrigemDestinoInput.End_EstadoOrigem =
                  resultado.Endereco.UnidadeFederativa;
                this.enderecoOrigemDestinoInput.End_NumeroOrigem =
                  resultado.Endereco.Numero;
                this.enderecoOrigemDestinoInput.Compl_Origem =
                  resultado.Endereco.Complemento;
                this.obterClienteEntidadePorCnpjOrigem(cnpj.toString());
                if (
                  this.enderecoOrigemDestinoInput.Doc_CnpjOrigem !=
                  this.propostaInput.Doc_CnpjContratante
                ) {
                  this.utilizaContratanteNaOrigem = true;
                  this.textoContratanteNaOrigem = 'Utilizar Contratante';
                }
              }
              break;
            case BwSStatus.NaoProcessado:
              {
                this.notifyService.Error(
                  'Atenção',
                  'CNPJ inexistente ou não encontrado.'
                );
                this.bloquearEdicaoRazaoSocialOrigem = true;
              }
              break;
            case BwSStatus.CNPJInvalido:
              {
                this.notifyService.Error('Atenção', 'CNPJ Inválido.');
                this.bloquearEdicaoRazaoSocialOrigem = true;
              }
              break;
            default:
              this.notifyService.Error(
                'Atenção',
                'Não foi possível consultar o CNPJ na Receita Federal para preenchimento automático dos dados do contratante. Os dados devem ser informados manualmente.'
              );
              this.bloquearEdicaoRazaoSocialOrigem = false;
              break;
          }
        },
        error => {
          this.limparDadosEnderecoOrigem(true);
          this.notifyService.Error(
            'Atenção',
            'Não foi possível consultar o CNPJ na Receita Federal para preenchimento automático dos dados do contratante. Os dados devem ser informados manualmente.'
          );
          this.bloquearEdicaoRazaoSocialOrigem = false;
        }
      );
    }
  }

  public obterClienteEntidadePorCnpjOrigem(cod_cnpj: string): void {
    let filtro = new Dados<FiltroClienteEntidadeInput>();

    filtro.Filtro = {
      Cod_Cnpj: cod_cnpj
    };
    filtro.Opcoes = {
      NomeCampo: 'ID_Entidade',
      PaginaAtual: 1,
      SentidoOrdenacao: Ordenacao.ASC,
      TamanhoPagina: 1
    };

    let observable = this.clienteEntidadeService.selecionar(filtro);
    observable.subscribe(resultado => {
      if (resultado.Dados.length > 0) {
        this.enderecoOrigemDestinoInput.COD_EntidadeOrigem =
          resultado.Dados[0].ID_Entidade;
        if (this.enderecoOrigemDestinoInput.Cod_EntidadeTpEnderecoOrig > 0)
          this.obterEntidadeEnderecoOrigem(
            this.enderecoOrigemDestinoInput.COD_EntidadeOrigem,
            this.enderecoOrigemDestinoInput.Cod_EntidadeTpEnderecoOrig
          );
      }
    });
  }

  public obterEntidadeEnderecoOrigem(
    cod_entidade: number,
    cod_EntidadeTpEndereco: number
  ): void {
    let filtro = new Dados<FiltroEntidadeEnderecoInput>();
    filtro.Filtro = {
      ID_Entidade: cod_entidade,
      ID_EntidadeTpEndereco: cod_EntidadeTpEndereco
    };
    filtro.Opcoes = {
      NomeCampo: 'ID_EntidadeEndereco',
      PaginaAtual: 1,
      SentidoOrdenacao: Ordenacao.ASC,
      TamanhoPagina: 1
    };
    this.enderecoOrigemDestinoInput.COD_EntidadeOrigem = null;
    let observable = this.entidadeEnderecoService.selecionar(filtro);
    observable.subscribe(resultado => {
      if (resultado.Dados.length > 0) {
        this.enderecoOrigemDestinoInput.COD_EntidadeEnderecoOrig =
          resultado.Dados[0].ID_EntidadeEndereco;
      }
    });
  }

  private _origemVazia(): boolean {
    return (
      !this.enderecoOrigemDestinoInput.Doc_CnpjOrigem &&
      !this.enderecoOrigemDestinoInput.Nom_RazaoSocialOrig &&
      !this.enderecoOrigemDestinoInput.End_CepOrigem &&
      !this.enderecoOrigemDestinoInput.End_Origem &&
      !this.enderecoOrigemDestinoInput.End_NumeroOrigem &&
      !this.enderecoOrigemDestinoInput.End_BairroOrigem &&
      !this.enderecoOrigemDestinoInput.Cid_Origem &&
      !this.enderecoOrigemDestinoInput.End_EstadoOrigem &&
      !this.enderecoOrigemDestinoInput.Compl_Origem
    );
  }

  public _contratanteOrigem(tipo: string): boolean {
    switch (tipo) {
      case '1':
        let tipoPontoOrigem = this.enderecoOrigemDestinoInput
          .Cod_EntidadeTpEnderecoOrig;
        if (tipoPontoOrigem) {
          if (this.utilizaContratanteNaOrigem) {
            this.utilizaContratanteNaOrigem = false;
            this.textoContratanteNaOrigem = 'Não utilizar Contratante';

            this.preencherContratanteOrigem();
          } else {
            this.utilizaContratanteNaOrigem = true;
            this.textoContratanteNaOrigem = 'Utilizar Contratante';

            this.limparOrigem();
          }
          break;
        } else {
          this.notifyService.Error(
            'Atenção',
            'Selecione o Tipo do Ponto na Origem'
          );
          return false;
        }
    }
    return false;
  }

  public preencherContratanteOrigem(): void {
    if (this.propostaInput) {
      this.enderecoOrigemDestinoInput.Doc_CnpjOrigem = this.propostaInput.Doc_CnpjContratante;
      this.enderecoOrigemDestinoInput.Nom_RazaoSocialOrig = this.propostaInput.Nom_RazaoSocial;
      this.enderecoOrigemDestinoInput.End_CepOrigem = this.propostaInput.End_CepContratante;
      this.enderecoOrigemDestinoInput.End_Origem = this.propostaInput.End_Contratante;
      this.enderecoOrigemDestinoInput.End_NumeroOrigem = this.propostaInput.End_Numero;
      this.enderecoOrigemDestinoInput.End_BairroOrigem = this.propostaInput.End_Bairro;
      this.enderecoOrigemDestinoInput.Cid_Origem = this.propostaInput.Cid_Contratante;
      this.enderecoOrigemDestinoInput.End_EstadoOrigem = this.propostaInput.End_EstadoContratante;
      this.enderecoOrigemDestinoInput.Compl_Origem = this.propostaInput.Compl_Contratante;
    }
  }

  public limparOrigem(): boolean {
    //this.enderecoOrigemDestinoInput = new EnderecoOrigemDestinoInput();

    this.enderecoOrigemDestinoInput.Doc_CnpjOrigem = '';
    this.enderecoOrigemDestinoInput.Nom_RazaoSocialOrig = '';
    this.enderecoOrigemDestinoInput.End_CepOrigem = '';
    this.enderecoOrigemDestinoInput.End_Origem = '';
    this.enderecoOrigemDestinoInput.End_NumeroOrigem = '';
    this.enderecoOrigemDestinoInput.End_BairroOrigem = '';
    this.enderecoOrigemDestinoInput.Cid_Origem = '';
    this.enderecoOrigemDestinoInput.End_EstadoOrigem = '';
    this.enderecoOrigemDestinoInput.Compl_Origem = '';

    this.escolheuFilialOrigem = false;
    this.utilizaContratanteNaOrigem = true;
    this.textoContratanteNaOrigem = 'Utilizar Contratante';

    this.clienteEntidadeOrigemViewModel = new ClienteEntidadeViewModel();
    this.clienteEntidadeOrigemViewModel.Nom_RazaoSocial = '';

    return false;
  }

  public escolherFilialEntidadeOrigem(): void {
    if (
      this.clienteEntidadeOrigemViewModel.Cod_CNPJ &&
      this.clienteEntidadeOrigemViewModel.Cod_CNPJ != ''
    ) {
      this.enderecoOrigemDestinoInput.Doc_CnpjOrigem = this.clienteEntidadeOrigemViewModel.Cod_CNPJ.substring(
        1
      );
      this.enderecoOrigemDestinoInput.Nom_RazaoSocialOrig = this.clienteEntidadeOrigemViewModel.Nom_RazaoSocial;
      this.enderecoOrigemDestinoInput.End_CepOrigem = this.clienteEntidadeOrigemViewModel.Cod_Cep;
      this.enderecoOrigemDestinoInput.End_Origem = this.clienteEntidadeOrigemViewModel.End_Cliente;
      this.enderecoOrigemDestinoInput.End_NumeroOrigem = this.clienteEntidadeOrigemViewModel.End_Numero;
      this.enderecoOrigemDestinoInput.End_BairroOrigem = this.clienteEntidadeOrigemViewModel.Nom_Bairro;
      this.enderecoOrigemDestinoInput.Cid_Origem = this.clienteEntidadeOrigemViewModel.Nom_Cidade;
      this.enderecoOrigemDestinoInput.End_EstadoOrigem = this.clienteEntidadeOrigemViewModel.Nom_Abvd_Estado;
      this.enderecoOrigemDestinoInput.Compl_Origem = this.clienteEntidadeOrigemViewModel.End_Complemento;

      this.escolheuFilialOrigem = true;

      this.utilizaContratanteNaOrigem = true;
      this.textoContratanteNaOrigem = 'Utilizar Contratante';
    } else {
      this.escolheuFilialOrigem = false;
    }
  }

  public tratamentoTipoPontoNaOrigem() {
    let valor = $(
      '#Operacional-EntidadeTpEnderecoOrigem option:selected'
    ).text();
    if (valor == 'Federal') {
      this.preencherContratanteOrigem();
      this.utilizaContratanteNaOrigem = false;
      this.textoContratanteNaOrigem = 'Não utilizar Contratante';
    } else {
      if (!this.utilizaContratanteNaOrigem) return;
      this.utilizaContratanteNaOrigem = true;
      this.textoContratanteNaOrigem = 'Utilizar Contratante';
    }
  }

  public filialClienteOrigemObservableSource(
    keyword: string
  ): Observable<Visualizacao<ClienteEntidadeViewModel>> {
    if (keyword) {
      let filtro = new Dados<FiltroClienteEntidadeInput>();
      filtro.Filtro = {
        Nom_RazaoSocial: keyword,
        ID_EntidadeSegmento: 35
      };
      filtro.Opcoes = {
        NomeCampo: 'Nom_RazaoSocial',
        PaginaAtual: 1,
        SentidoOrdenacao: Ordenacao.ASC,
        TamanhoPagina: 30
      };
      return this.clienteEntidadeService.selecionar(filtro);
    } else {
      return Observable.of(new Visualizacao<ClienteEntidadeViewModel>());
    }
  }

  public autocompleListFormatterFilialOrigem = (
    data: ClienteEntidadeViewModel
  ) => {
    let CnpjMascarado = this.mascaraCnpjOrigem(data.Cod_CNPJ.substring(1));
    let html = `<span style="font-size:12px;">RAZAO: ${
      data.Nom_RazaoSocial
    } <br>CNPJ: ${CnpjMascarado} - ${data.Nom_Cidade}/${
      data.Nom_Abvd_Estado
    } <br>FANTASIA: ${data.Nom_Fantasia}</span>`;
    return this._sanitizer.bypassSecurityTrustHtml(html);
  };

  public mascaraCnpjOrigem(valor): string {
    return valor.replace(
      /(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/g,
      '$1.$2.$3/$4-$5'
    );
  }

  // ------------------------------------------- DESTINO :
  public consultarCepDestino(cep: number): void {
    if (cep) {
      if(cep.toString().length !== 8) {
        this.notifyService.Error('Atenção', 'CEP inválido');
        return;
      }
      let observable = this.bwsService.consultarCep(cep);
      observable.subscribe(
        resultado => {
          this.limparDadosEnderecoDestino(false);
          if (resultado.Status == 1) {
            this.enderecoOrigemDestinoInput.End_BairroDestino =
              resultado.Bairro;
            this.enderecoOrigemDestinoInput.End_Destino = resultado.Logradouro;
            this.enderecoOrigemDestinoInput.Cid_Destino = resultado.Cidade;
            this.enderecoOrigemDestinoInput.End_EstadoDestino =
              resultado.UnidadeFederativa;
            this.enderecoOrigemDestinoInput.Compl_Destino =
              resultado.BairroComplemento;
            this.enderecoOrigemDestinoInput.End_NumeroDestino = undefined;
          }
        },
        error => {
          this.limparDadosEnderecoDestino(false);
        }
      );
    }
  }

  private limparDadosEnderecoDestino(destinoConsultaCnpj: boolean) {
    this.enderecoOrigemDestinoInput.End_BairroDestino = undefined;
    if (destinoConsultaCnpj) {
      this.enderecoOrigemDestinoInput.End_CepDestino = undefined;
      this.enderecoOrigemDestinoInput.Nom_RazaoSocialDest = undefined;
    }
    this.enderecoOrigemDestinoInput.End_Destino = undefined;
    this.enderecoOrigemDestinoInput.Cid_Destino = undefined;
    this.enderecoOrigemDestinoInput.End_NumeroDestino = undefined;
    this.enderecoOrigemDestinoInput.Compl_Destino = undefined;
    this.enderecoOrigemDestinoInput.End_EstadoDestino = undefined;
  }

  public consultarCnpjDestino(cnpj: number): void {
    if (cnpj) {
      let observable = this.bwsService.consultarCnpj(cnpj);
      observable.subscribe(
        resultado => {
          this.limparDadosEnderecoDestino(true);
          let status = resultado ? resultado.Status : BwSStatus.ErroInterno;
          switch (status) {
            case BwSStatus.Sucesso:
              {
                this.bloquearEdicaoRazaoSocialDestino = true;
                this.enderecoOrigemDestinoInput.End_BairroDestino =
                  resultado.Endereco.Bairro;
                if (resultado.Endereco.CEP)
                  this.enderecoOrigemDestinoInput.End_CepDestino = _.padStart(
                    resultado.Endereco.CEP.toString(),
                    8,
                    '0'
                  );
                this.enderecoOrigemDestinoInput.Nom_RazaoSocialDest =
                  resultado.RazaoSocial;
                this.enderecoOrigemDestinoInput.End_Destino =
                  resultado.Endereco.Logradouro;
                this.enderecoOrigemDestinoInput.Cid_Destino =
                  resultado.Endereco.Cidade;
                this.enderecoOrigemDestinoInput.End_EstadoDestino =
                  resultado.Endereco.UnidadeFederativa;
                this.enderecoOrigemDestinoInput.End_NumeroDestino =
                  resultado.Endereco.Numero;
                this.enderecoOrigemDestinoInput.Compl_Destino =
                  resultado.Endereco.Complemento;
                this.obterClienteEntidadePorCnpjDestino(cnpj.toString());
                if (
                  this.enderecoOrigemDestinoInput.Doc_CnpjDestino !=
                  this.propostaInput.Doc_CnpjContratante
                ) {
                  this.utilizaContratanteNaOrigem = true;
                  this.textoContratanteNaOrigem = 'Utilizar Contratante';
                }
              }
              break;
            case BwSStatus.NaoProcessado:
              {
                this.notifyService.Error(
                  'Atenção',
                  'CNPJ inexistente ou não encontrado.'
                );
                this.bloquearEdicaoRazaoSocialDestino = true;
              }
              break;
            case BwSStatus.CNPJInvalido:
              {
                this.notifyService.Error('Atenção', 'CNPJ Inválido.');
                this.bloquearEdicaoRazaoSocialDestino = true;
              }
              break;
            default:
              this.notifyService.Error(
                'Atenção',
                'Não foi possível consultar o CNPJ na Receita Federal para preenchimento automático dos dados do contratante. Os dados devem ser informados manualmente.'
              );
              this.bloquearEdicaoRazaoSocialDestino = false;
              break;
          }
        },
        error => {
          this.limparDadosEnderecoDestino(true);
          this.notifyService.Error(
            'Atenção',
            'Não foi possível consultar o CNPJ na Receita Federal para preenchimento automático dos dados do contratante. Os dados devem ser informados manualmente.'
          );
          this.bloquearEdicaoRazaoSocialDestino = false;
        }
      );
    }
  }

  public obterClienteEntidadePorCnpjDestino(cod_cnpj: string): void {
    let filtro = new Dados<FiltroClienteEntidadeInput>();

    filtro.Filtro = {
      Cod_Cnpj: cod_cnpj
    };
    filtro.Opcoes = {
      NomeCampo: 'ID_Entidade',
      PaginaAtual: 1,
      SentidoOrdenacao: Ordenacao.ASC,
      TamanhoPagina: 1
    };

    let observable = this.clienteEntidadeService.selecionar(filtro);
    observable.subscribe(resultado => {
      if (resultado.Dados.length > 0)
        this.enderecoOrigemDestinoInput.COD_EntidadeDestino =
          resultado.Dados[0].ID_Entidade;
      if (this.enderecoOrigemDestinoInput.Cod_EntidadeTpEnderecoDest > 0)
        this.obterEntidadeEnderecoOrigem(
          this.enderecoOrigemDestinoInput.COD_EntidadeDestino,
          this.enderecoOrigemDestinoInput.Cod_EntidadeTpEnderecoDest
        );
    });
  }

  public obterEntidadeEnderecoDestino(
    cod_entidade: number,
    cod_EntidadeTpEndereco: number
  ): void {
    let filtro = new Dados<FiltroEntidadeEnderecoInput>();
    filtro.Filtro = {
      ID_Entidade: cod_entidade,
      ID_EntidadeTpEndereco: cod_EntidadeTpEndereco
    };
    filtro.Opcoes = {
      NomeCampo: 'ID_EntidadeEndereco',
      PaginaAtual: 1,
      SentidoOrdenacao: Ordenacao.ASC,
      TamanhoPagina: 1
    };
    this.enderecoOrigemDestinoInput.COD_EntidadeDestino = null;
    let observable = this.entidadeEnderecoService.selecionar(filtro);
    observable.subscribe(resultado => {
      if (resultado.Dados.length > 0) {
        this.enderecoOrigemDestinoInput.COD_EntidadeEnderecoDest =
          resultado.Dados[0].ID_EntidadeEndereco;
      }
    });
  }

  public _contratanteDestino(tipo: string): boolean {
    switch (tipo) {
      case '1':
        let tipoPontoDestino = this.enderecoOrigemDestinoInput
          .Cod_EntidadeTpEnderecoDest;
        if (tipoPontoDestino) {
          if (
            this.utilizaContratanteNoDestino &&
            !this.enderecoOrigemDestinoInput.Doc_CnpjDestino
          ) {
            this.utilizaContratanteNoDestino = false;
            this.textoContratanteNoDestino = 'Não utilizar Contratante';

            this.onInit = false;

            this.preencherContratanteDestino();
          } else {
            this.utilizaContratanteNoDestino = true;
            this.textoContratanteNoDestino = 'Utilizar Contratante';

            if (
              !this.enderecoOrigemDestinoInput.Doc_CnpjDestino ||
              !this.onInit
            ) {
              this.limparDestino();
            }

            this.onInit = false;
          }
          break;
        } else {
          this.notifyService.Error(
            'Atenção',
            'Selecione o Tipo do Ponto no Destino'
          );
          return false;
        }
    }
    return false;
  }

  public preencherContratanteDestino(): void {
    if (this.propostaInput) {
      this.enderecoOrigemDestinoInput.Doc_CnpjDestino = this.propostaInput.Doc_CnpjContratante;
      this.enderecoOrigemDestinoInput.Nom_RazaoSocialDest = this.propostaInput.Nom_RazaoSocial;
      this.enderecoOrigemDestinoInput.End_CepDestino = this.propostaInput.End_CepContratante;
      this.enderecoOrigemDestinoInput.End_Destino = this.propostaInput.End_Contratante;
      this.enderecoOrigemDestinoInput.End_NumeroDestino = this.propostaInput.End_Numero;
      this.enderecoOrigemDestinoInput.End_BairroDestino = this.propostaInput.End_Bairro;
      this.enderecoOrigemDestinoInput.Cid_Destino = this.propostaInput.Cid_Contratante;
      this.enderecoOrigemDestinoInput.End_EstadoDestino = this.propostaInput.End_EstadoContratante;
      this.enderecoOrigemDestinoInput.Compl_Destino = this.propostaInput.Compl_Contratante;
    }
  }

  public limparDestino(): boolean {
    //this.enderecoOrigemDestinoInput = new EnderecoOrigemDestinoInput();

    this.enderecoOrigemDestinoInput.Doc_CnpjDestino = '';
    this.enderecoOrigemDestinoInput.Nom_RazaoSocialDest = '';
    this.enderecoOrigemDestinoInput.End_CepDestino = '';
    this.enderecoOrigemDestinoInput.End_Destino = '';
    this.enderecoOrigemDestinoInput.End_NumeroDestino = '';
    this.enderecoOrigemDestinoInput.End_BairroDestino = '';
    this.enderecoOrigemDestinoInput.Cid_Destino = '';
    this.enderecoOrigemDestinoInput.End_EstadoDestino = '';
    this.enderecoOrigemDestinoInput.Compl_Destino = '';

    this.escolheuFilialDestino = false;
    this.utilizaContratanteNoDestino = true;
    this.textoContratanteNoDestino = 'Utilizar Contratante';

    this.clienteEntidadeDestinoViewModel = new ClienteEntidadeViewModel();
    this.clienteEntidadeDestinoViewModel.Nom_RazaoSocial = '';

    return false;
  }

  public escolherFilialEntidadeDestino(): void {
    if (
      this.clienteEntidadeDestinoViewModel.Cod_CNPJ &&
      this.clienteEntidadeDestinoViewModel.Cod_CNPJ != ''
    ) {
      this.enderecoOrigemDestinoInput.Doc_CnpjDestino = this.clienteEntidadeDestinoViewModel.Cod_CNPJ.substring(
        1
      );
      this.enderecoOrigemDestinoInput.Nom_RazaoSocialDest = this.clienteEntidadeDestinoViewModel.Nom_RazaoSocial;
      this.enderecoOrigemDestinoInput.End_CepDestino = this.clienteEntidadeDestinoViewModel.Cod_Cep;
      this.enderecoOrigemDestinoInput.End_Destino = this.clienteEntidadeDestinoViewModel.End_Cliente;
      this.enderecoOrigemDestinoInput.End_NumeroDestino = this.clienteEntidadeDestinoViewModel.End_Numero;
      this.enderecoOrigemDestinoInput.End_BairroDestino = this.clienteEntidadeDestinoViewModel.Nom_Bairro;
      this.enderecoOrigemDestinoInput.Cid_Destino = this.clienteEntidadeDestinoViewModel.Nom_Cidade;
      this.enderecoOrigemDestinoInput.End_EstadoDestino = this.clienteEntidadeDestinoViewModel.Nom_Abvd_Estado;
      this.enderecoOrigemDestinoInput.Compl_Destino = this.clienteEntidadeDestinoViewModel.End_Complemento;

      this.escolheuFilialDestino = true;
      this.utilizaContratanteNoDestino = true;
      this.textoContratanteNoDestino = 'Utilizar Contratante';
    } else {
      this.escolheuFilialDestino = false;
    }
  }

  public tratamentoTipoPontoNoDestino() {
    let valor = $(
      '#Operacional-EntidadeTpEnderecoDestino option:selected'
    ).text();
    if (valor == 'Federal') {
      this.preencherContratanteDestino();
      this.utilizaContratanteNoDestino = false;
      this.textoContratanteNoDestino = 'Não utilizar Contratante';
    } else {
      if (!this.utilizaContratanteNoDestino) return;
      this.utilizaContratanteNoDestino = true;
      this.textoContratanteNoDestino = 'Utilizar Contratante';
    }
  }

  public filialClienteDestinoObservableSource(
    keyword: string
  ): Observable<Visualizacao<ClienteEntidadeViewModel>> {
    if (keyword) {
      let filtro = new Dados<FiltroClienteEntidadeInput>();
      filtro.Filtro = {
        Nom_RazaoSocial: keyword,
        ID_EntidadeSegmento: 35
      };
      filtro.Opcoes = {
        NomeCampo: 'Nom_RazaoSocial',
        PaginaAtual: 1,
        SentidoOrdenacao: Ordenacao.ASC,
        TamanhoPagina: 30
      };
      return this.clienteEntidadeService.selecionar(filtro);
    } else {
      return Observable.of(new Visualizacao<ClienteEntidadeViewModel>());
    }
  }

  public autocompleListFormatterFilialDestino = (
    data: ClienteEntidadeViewModel
  ) => {
    let CnpjMascarado = this.mascaraCnpjOrigem(data.Cod_CNPJ.substring(1));
    let html = `<span style="font-size:12px;">RAZAO: ${
      data.Nom_RazaoSocial
    } <br>CNPJ: ${CnpjMascarado} - ${data.Nom_Cidade}/${
      data.Nom_Abvd_Estado
    } <br>FANTASIA: ${data.Nom_Fantasia}</span>`;
    return this._sanitizer.bypassSecurityTrustHtml(html);
  };

  public mascaraCnpjDestino(valor): string {
    return valor.replace(
      /(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/g,
      '$1.$2.$3/$4-$5'
    );
  }

  // INICIO - CUSTOMIZACAO BANCO E FILIAL NO FILHO DO PONTO
  public filialObservableSource(
    keyword: string
  ): Observable<Visualizacao<FilialViewModel>> {
    if (keyword) {
      let filtro = new Dados<FiltroFilialInput>();
      filtro.Filtro = {
        Nom_Filial: keyword
      };
      filtro.Opcoes = this.obterOpcoesPadrao('Nom_Filial');

      return this.filialService.selecionar(filtro);
    } else {
      return Observable.of(new Visualizacao<FilialViewModel>());
    }
  }

  public entidadeBancoObservableSource(
    keyword: string
  ): Observable<Visualizacao<EntidadeBancoViewModel>> {
    if (keyword) {
      let filtro = new Dados<FiltroEntidadeBancoInput>();
      filtro.Filtro = {
        Nom_Banco: keyword
      };
      filtro.Opcoes = this.obterOpcoesPadrao('Nom_Banco');
      return this.entidadeBancoService.selecionar(filtro);
    } else {
      return Observable.of(new Visualizacao<EntidadeBancoViewModel>());
    }
  }

  public modeloCofreObservableSource(
    keyword: string
  ): Observable<Visualizacao<TipoEquipamentoViewModel>> {
    let filtro = new Dados<FiltroTipoEquipamentoInput>();
      filtro.Filtro = {
        Des_TpEquipamento: keyword
      };
      filtro.Opcoes = this.obterOpcoesPadrao('Des_TpEquipamento');
      return this.tipoEquipamentoService.selecionar(filtro);
  }

  public obterAgencias(
    agenciaBanco: EntidadeBancoViewModel,
    preencherEntidade: boolean = false
  ) {
    if (!agenciaBanco) {
      this.agencias = [];
      this.entidadeAgenciaViewModel = null;
      return;
    }

    this.entidadeBancoService
      .obterAgencias(agenciaBanco.ID_EntidadeBanco)
      .subscribe(
        result => {
          this.agencias = result.Dados;
          if (preencherEntidade) {
            this.entidadeAgenciaViewModel = _.find(result.Dados, x => String(x.ID_EntidadeAgencia) == this.enderecoOrigemDestinoInput.COD_EntidadeAgencia);

            if (this.entidadeAgenciaViewModel == undefined){
              this.entidadeAgenciaViewModel = new EntidadeAgenciaViewModel();
              this.entidadeAgenciaViewModel.Cod_Agencia = this.padLeft(this.enderecoOrigemDestinoInput.COD_EntidadeAgencia, '0', 4);
            }

          }

        },
        error => {
          this.notifyService.HttpError('Erro ao obter agencias', error);
        }
      );
  }

  public autocompleListFormatterFilial = (data: FilialViewModel) => {
    let html = `<span style="font-size:12px;">NOME: ${
      data.Nom_Filial
    } <br>CGC: ${data.Cod_Cgc} <br>SIGLA: ${data.Nom_Abvd_Filial}</span>`;
    return this._sanitizer.bypassSecurityTrustHtml(html);
  };

  public obterOpcoesPadrao(campoOrdenacao: string): Opcoes {
    return {
      NomeCampo: campoOrdenacao,
      PaginaAtual: 1,
      TamanhoPagina: 255,
      SentidoOrdenacao: Ordenacao.ASC
    };
  }

  public onBlurFilial(): void {
    let filialValido =
      this.filialViewModelPai && this.filialViewModelPai.Cod_Filial > 0;
    if (!filialValido) {
      this.filialViewModelPai = undefined;
    } else {
      // preencherDadosDestinoComFilialBrinks();
    }
  }

  private preencherDadosDestinoComFilialBrinks(): void {
    const enderecoCompleto = this.filialViewModelPai.End_Filial;
    const logradouro = enderecoCompleto.substring(
      0,
      enderecoCompleto.indexOf(','),
    );
    const numeroComplementoBairroCidadeEstado = enderecoCompleto.substring(
      enderecoCompleto.indexOf(',') + 1,
      enderecoCompleto.length,
    );
    const numero = numeroComplementoBairroCidadeEstado.substring(
      0,
      numeroComplementoBairroCidadeEstado.indexOf(',')
    );
    const complementoBairroCidadeEstado = numeroComplementoBairroCidadeEstado.substring(
      numeroComplementoBairroCidadeEstado.indexOf(',') + 1,
      numeroComplementoBairroCidadeEstado.length,
    );
    const complemento = complementoBairroCidadeEstado.substring(
      0,
      complementoBairroCidadeEstado.indexOf(','),
    );
    const bairroCidadeEstado = complementoBairroCidadeEstado.substring(
      complementoBairroCidadeEstado.indexOf(',') + 1,
      complementoBairroCidadeEstado.length,
    );
    const bairro = bairroCidadeEstado.substring(
      0,
      bairroCidadeEstado.indexOf(','),
    );

    if (this.filialViewModelPai.Cod_Cgc.length > 14) {
      this.enderecoOrigemDestinoInput.Doc_CnpjDestino = this.filialViewModelPai.Cod_Cgc.substring(1); //CNPJ
    }
    this.enderecoOrigemDestinoInput.Nom_RazaoSocialDest = this.filialViewModelPai.Nom_Filial; //Razao Social
    this.enderecoOrigemDestinoInput.End_CepDestino = this.filialViewModelPai.Cep_Filial; // CEP

    this.enderecoOrigemDestinoInput.End_Destino = logradouro.trim(); //ENDERECO
    this.enderecoOrigemDestinoInput.End_NumeroDestino = numero.trim(); //NUMERO
    this.enderecoOrigemDestinoInput.End_BairroDestino = this.filialViewModelPai.Bairro_Filial; // BAIRRO

    this.enderecoOrigemDestinoInput.Cid_Destino = this.filialViewModelPai.Cidade; //CIDADE
    this.enderecoOrigemDestinoInput.End_EstadoDestino = this.filialViewModelPai.SiglaEstado; //Estado
    this.enderecoOrigemDestinoInput.Compl_Destino = complemento.trim(); //Complemento

    this.alterouFilial = true;
  }

  private obterFilial(cod_Filial: number, cod_regional: number): void {
    let filtro = new Dados<FiltroFilialInput>();
    filtro.Opcoes = {
      NomeCampo: 'Cod_Filial',
      PaginaAtual: 1,
      SentidoOrdenacao: Ordenacao.ASC,
      TamanhoPagina: 255
    };
    filtro.Filtro = {
      Cod_Filial: cod_Filial,
      Cod_Regional: cod_regional
    };

    let observable = this.filialService.selecionar(filtro);

    observable.subscribe(
      resultado => {
        this.filialViewModelPai = resultado.Dados[0];
        //this.obterRegional(this.filialViewModel.Cod_Regional)
      },
      error => {
        this.notifyService.HttpError('Atenção', error);
      }
    );
  }

  private obterEntidadeBanco(ID_EntidadeBanco: number): void {
    let observable = this.entidadeBancoService.obter(ID_EntidadeBanco);

    observable.subscribe(
      resultado => {
        this.entidadeBancoViewModel = resultado;
        if (this.entidadeBancoViewModel && this.enderecoOrigemDestinoInput.COD_EntidadeAgencia)
          this.obterAgencias(this.entidadeBancoViewModel, true);
      },
      error => {
        this.notifyService.HttpError('Atenção', error);
      }
    );
  }

  public newFilialOrigemDoModal(): void {
    const activeModal = this.modalService.open(
      EnderecoOrigemDestinoFilialComponent,
      { size: 'sm' }
    );

    const componentInstance: EnderecoOrigemDestinoFilialComponent =
      activeModal.componentInstance;

    componentInstance.onEnderecoOrigemDestinoFilialAdicionado.subscribe(
      (resultado: ClienteEntidadeInput) => {
        this.clienteEntidadeOrigemViewModel = resultado;
        this.escolherFilialEntidadeOrigem();
      }
    );
  }

  public newFilialDestinoDoModal(): void {
    const activeModal = this.modalService.open(
      EnderecoOrigemDestinoFilialComponent,
      { size: 'sm' }
    );

    const componentInstance: EnderecoOrigemDestinoFilialComponent =
      activeModal.componentInstance;

    componentInstance.onEnderecoOrigemDestinoFilialAdicionado.subscribe(
      (resultado: ClienteEntidadeInput) => {
        this.clienteEntidadeDestinoViewModel = resultado;
        this.escolherFilialEntidadeDestino();
      }
    );
  }

  onDateChange() {
    this.picker.dialogVisible = false;
  }

  parseDate() {
    let str = (<HTMLInputElement>document.getElementById('baseDateTime')).value;
    str = '01/' + str;
    let m = str.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    return m ? new Date(+m[3], +m[2] - 1, +m[1]) : null;
  }
  // FIM - CUSTOMIZACAO BANCO E FILIAL NO FILHO DO PONTO


  formataData(event:any){
    if (event.keyCode != 8){
      if((<HTMLInputElement>document.getElementById('baseDateTime')).value.length ==2 && (event.keyCode != 111 && event.keyCode != 193)){
        (<HTMLInputElement>document.getElementById('baseDateTime')).value = (<HTMLInputElement>document.getElementById('baseDateTime')).value + "/";
      }
    }
  }

  onChangeModalidadeCreditoD0() {
    this.modalidadecreditoD1 = false;

    this.setModadalidadeCreditoValue();
  }

  onChangeModalidadeCreditoD1() {
    this.modalidadecreditoD0 = false;

    this.setModadalidadeCreditoValue();
  }

  onChangeFLGImpressaoEnderecoDestino(){
    this.enderecoOrigemDestinoInput.FLG_ImpressaoEnderecoDestino = this.flgImpressaoEnderecoDestino ;
  }
  private setModadalidadeCreditoValue() {
    if(this.modalidadecreditoD0 && !this.modalidadecreditoD1) {
      this.enderecoOrigemDestinoInput.VL_ModalidadeCredito = 0;
      return;
    }

    if(!this.modalidadecreditoD0 && this.modalidadecreditoD1) {
      this.enderecoOrigemDestinoInput.VL_ModalidadeCredito = 1;
      return;
    }

    this.enderecoOrigemDestinoInput.VL_ModalidadeCredito = null;
  }

  padLeft(text:string, padChar:string, size:number): string {
    return (String(padChar).repeat(size) + text).substr( (size * -1), size) ;
  }

  alterarCepOrigem(newValue) {
    const value = newValue.replace('-', '');

    if (this.enderecoOrigemDestinoInput.End_CepOrigem === value) {
      return;
    }

    if (!this.escolheuFilialOrigem) {
      this.limparDadosEnderecoOrigem(false);
    }

    this.enderecoOrigemDestinoInput.End_CepOrigem = value;
  }

  alterarCepDestino(newValue) {
    const value = newValue.replace('-', '');

    if (this.enderecoOrigemDestinoInput.End_CepDestino === value) {
      return;
    }

    if (!this.escolheuFilialDestino && !this.alterouFilial) {
      this.limparDadosEnderecoDestino(false);
    }

    this.enderecoOrigemDestinoInput.End_CepDestino = value;
    this.alterouFilial = false;
  }

}
