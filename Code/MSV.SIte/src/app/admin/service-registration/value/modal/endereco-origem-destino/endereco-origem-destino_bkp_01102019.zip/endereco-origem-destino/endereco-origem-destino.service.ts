import { Injectable, Inject } from '@angular/core';
import { HttpBaseService } from 'app/utils/httpBase.service';
import { InjectorHttpService } from 'app/utils/injectorHttp.service';
import { APIConfig } from 'app/app.config';
import { environment } from 'environments/environment';
import { EnderecoOrigemDestinoInput } from 'app/pages/propostas/proposta-steps/ponto-atendimento/endereco-origem-destino/inputs/EnderecoOrigemDestinoInput.model';
import { EnderecoOrigemDestinoViewModel } from 'app/pages/propostas/proposta-steps/ponto-atendimento/endereco-origem-destino/viewModels/EnderecoOrigemDestinoViewModel.model';
import { FiltroEnderecoOrigemDestinoInput } from 'app/pages/propostas/proposta-steps/ponto-atendimento/endereco-origem-destino/inputs/FiltroEnderecoOrigemDestinoInput.model';
import * as _ from 'lodash';
import { Observable } from 'rxjs';
import { BlobService } from 'app/utils/blob.service';
import { EnderecoOrigemDestinoImportacaoViewModel } from './viewModels/EnderecoOrigemDestinoImportacaoViewModel.model';

@Injectable()
export class EnderecoOrigemDestinoService extends HttpBaseService<EnderecoOrigemDestinoInput, EnderecoOrigemDestinoViewModel, FiltroEnderecoOrigemDestinoInput, number> {

    constructor(
      @Inject(InjectorHttpService) public injectorHttpService: InjectorHttpService, public blobService: BlobService,) {
        super(injectorHttpService, APIConfig.Sites.Portal.Recursos.EnderecoOrigemDestino, environment.apiUrl);
    }

  public importar(worksheet: EnderecoOrigemDestinoInput[]): Observable<EnderecoOrigemDestinoImportacaoViewModel> {
    let uri = this.urlBase + APIConfig.Sites.Portal.Recursos.EnderecoOrigemDestino.importar;
    return this.http.post(uri, worksheet, this.getRequestOptions(this.header.ContentType.json)).map((res) => res.json());
  }

  public downloadModelo(compusafe: boolean): Observable<{ success: boolean, error?: any }> {
    return this.http.get(this.urlBase + APIConfig.Sites.Portal.Recursos.EnderecoOrigemDestino.downloadModelo + compusafe, this.getRequestOptions(this.header.ContentType.json, this.header.ResponseType.blob)).map(
      (res) => {
        try {
            let excelInfo = res.json();
            this.blobService.DownloadBlobURL(excelInfo.Result.Dados, excelInfo.Result.NomeArquivo);
            return {
                success: true
            };
        } catch (err) {
            return {
                success: false,
                error: err
            };
        }
      }, (error) => {
          console.log(error);
      });
    }
  }
